package constants

const (
	// db table
	CALL_BACK_LOG = "CallbackLog"
)
