Twilio Message Callback
---------------------
This is a sample folder for incase business expands to SMS tracking.
In addition to MailGun above provider can be used to track customer actions on SMS.
Listen to the event and parse it to common model with necessary details and save to storage.

 
